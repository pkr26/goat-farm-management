"""Breed presets and production-system variants.

Presets are built by factory functions (preferred, since they return fresh
models) and also collected in ``BREED_PRESETS`` for lookup by name. Numbers are
approximate literature values for Indian conditions; non-obvious figures carry
a short source comment. Weight curves are scaled from the Osmanabadi stall-fed
curve in proportion to each breed's yearling weight (NBAGR breed descriptors).
"""

from typing import Literal, get_args

from .assumptions import (
    SEMI_INTENSIVE_WEIGHT_CURVE,
    STALL_FED_WEIGHT_CURVE,
    GrowthAssumptions,
    HerdAssumptions,
    MortalityAssumptions,
    ReproductionAssumptions,
    SalesAssumptions,
    SimulationAssumptions,
)
from .market import bakrid_festival_months

System = Literal["stall_fed", "semi_intensive"]

# Derived from the Literal (never a hand-maintained copy) so the API layer's
# list of production systems can't drift from the type.
SYSTEMS: list[str] = list(get_args(System))


def _semi_intensive_weights(stall_fed: list[float]) -> list[float]:
    """This breed's semi-intensive (CIRG field) weight curve.

    Every preset's stall-fed table is the Osmanabadi stall-fed curve scaled
    to the breed's yearling weight; the field curve must carry the same
    ratio (anchored on the breed's own birth weight) instead of dropping the
    raw Osmanabadi CIRG numbers onto, say, a Jamunapari.
    """
    base = list(STALL_FED_WEIGHT_CURVE)
    cirg = list(SEMI_INTENSIVE_WEIGHT_CURVE)
    factor = (stall_fed[-1] - stall_fed[0]) / (base[-1] - base[0])
    return [stall_fed[0] + (w - cirg[0]) * factor for w in cirg]


def apply_system(a: SimulationAssumptions, system: System) -> SimulationAssumptions:
    """Return a copy of ``a`` adjusted for the production system.

    Semi-intensive: ~30% of DM comes free from grazing; field exposure raises
    kid and adult mortality relative to stall feeding (TNAU/ICAR comparisons of
    stall-fed vs grazing systems); and growth follows the CIRG field curve
    (roughly half the stall-fed gains to 3 months) — slower-growing animals
    that also eat less purchased feed. Leaving the stall-fed weight table in
    place while granting the grazing discount priced semi-intensive plans as
    stall-fed sales on grazing costs, systematically optimistic in a
    compounding direction (2026-09-20 audit P2-7).
    """
    if system == "stall_fed":
        return a.model_copy(deep=True)
    if system == "semi_intensive":
        variant = a.model_copy(deep=True)
        variant.feed.grazing_dm_fraction = 0.3  # TNAU semi-intensive budgets
        variant.growth.growth_regime = "semi_intensive"
        # Mutating the regime alone does not re-derive an already-materialized
        # table (GrowthAssumptions derives it only at construction), so swap
        # the table explicitly, scaled to this breed's yearling weight.
        variant.growth.weight_by_age_months = _semi_intensive_weights(
            variant.growth.weight_by_age_months
        )
        # An uplift, not an assignment: the docstring promises field exposure
        # *raises* mortality relative to stall feeding, but a flat assignment
        # left the already-fragile breeds (Black Bengal sits at 0.12 stall-fed)
        # showing the grazing feed saving with no offsetting loss at all.
        # round() keeps the stall-fed floors exact (0.05 + 0.01 is
        # 0.060000000000000005 in binary float) while still lifting a breed
        # that already sits at or above them.
        variant.mortality.adult = min(0.9, max(0.06, round(variant.mortality.adult + 0.01, 6)))
        variant.mortality.kid_pre_weaning = min(
            0.9, max(0.12, round(variant.mortality.kid_pre_weaning + 0.02, 6))
        )
        return variant
    raise ValueError(f"unknown production system: {system!r}")


def _osmanabadi_weights() -> list[float]:
    # Osmanabadi stall-fed curve: 2.5 kg birth, ~2 kg/month to yearling (NBAGR).
    return [2.5 + 2.0 * m for m in range(13)]


def _scaled_weights(factor: float, birth_weight: float) -> list[float]:
    """Scale the Osmanabadi curve to another breed's yearling weight."""
    base = _osmanabadi_weights()
    return [birth_weight + (w - base[0]) * factor for w in base]


def osmanabadi(system: System = "stall_fed") -> SimulationAssumptions:
    """Osmanabadi (default): meat breed, no saleable milk, 50 does + 2 bucks.

    The base defaults already carry the Telangana 2025-26 price and cost
    calibration, auto-fill the Bakrid festival months for the run's own
    horizon, and hold males finishing near a festival for the festival sale —
    the largest price event of the year is priced from month 1.

    DECIDED (2026-10-01 audit, 08-M7 → decision 2026-10-02): this preset is
    the sourced, stress-conservative REFERENCE unit, and it stays that way.
    Re-baselining toward a bankable-plausible unit was evaluated and rejected
    on modeling-integrity grounds — every input is cited, the unit needs
    ≈₹457/kg vs the sourced ₹370/kg market to break even, and neither
    unlevering (≈ −₹8.8 lakh NPV) nor the semi-intensive system (≈ −₹12.3
    lakh) closes the gap, so only unsourced input tuning would. The run's
    narrative carries those diagnostics. Full rationale in
    assumptions.py's decision record.
    """
    a = SimulationAssumptions()
    a.sales.festival_sale_months = bakrid_festival_months(
        a.meta.start_year_month, a.meta.horizon_months
    )
    return apply_system(a, system)


def sirohi(system: System = "stall_fed") -> SimulationAssumptions:
    """Sirohi: heavier dual-purpose breed, mostly single kids."""
    a = SimulationAssumptions(
        herd=HerdAssumptions(
            doe_purchase_price=9000.0,  # NABARD unit costs, heavier breed
            buck_purchase_price=14000.0,
        ),
        reproduction=ReproductionAssumptions(
            litter_size=1.4,  # NBAGR: ~70% singles
            # Larger frame matures later than the Osmanabadi floor.
            age_at_first_breeding_months=12,
        ),
        growth=GrowthAssumptions(
            birth_weight_kg=3.0,
            adult_weight_doe_kg=40.0,  # NBAGR breed descriptor
            adult_weight_buck_kg=50.0,
            weight_by_age_months=_scaled_weights(1.18, 3.0),
        ),
    )
    return apply_system(a, system)


def barbari(system: System = "stall_fed") -> SimulationAssumptions:
    """Barbari: compact, early-maturing, highly prolific stall-feeding breed."""
    a = SimulationAssumptions(
        herd=HerdAssumptions(
            doe_purchase_price=7000.0,
            buck_purchase_price=10000.0,
        ),
        reproduction=ReproductionAssumptions(
            litter_size=1.8,  # NBAGR: twins common
            age_at_first_breeding_months=10,
        ),
        growth=GrowthAssumptions(
            birth_weight_kg=2.0,
            adult_weight_doe_kg=27.0,  # NBAGR breed descriptor
            adult_weight_buck_kg=30.0,
            weight_by_age_months=_scaled_weights(0.85, 2.0),
            sale_age_months=8,
        ),
    )
    return apply_system(a, system)


def jamunapari(system: System = "stall_fed") -> SimulationAssumptions:
    """Jamunapari: large dual-purpose breed, slower maturity."""
    a = SimulationAssumptions(
        herd=HerdAssumptions(
            doe_purchase_price=11000.0,
            buck_purchase_price=16000.0,
        ),
        reproduction=ReproductionAssumptions(
            litter_size=1.3,  # NBAGR: mostly singles
            age_at_first_breeding_months=15,
        ),
        growth=GrowthAssumptions(
            birth_weight_kg=3.5,
            adult_weight_doe_kg=45.0,  # NBAGR breed descriptor
            adult_weight_buck_kg=55.0,
            weight_by_age_months=_scaled_weights(1.3, 3.5),
        ),
    )
    return apply_system(a, system)


def beetal(system: System = "stall_fed") -> SimulationAssumptions:
    """Beetal: large dual-purpose Punjab breed, good prolificacy."""
    a = SimulationAssumptions(
        herd=HerdAssumptions(
            doe_purchase_price=10000.0,
            buck_purchase_price=15000.0,
        ),
        reproduction=ReproductionAssumptions(
            litter_size=1.6,
            age_at_first_breeding_months=14,
        ),
        growth=GrowthAssumptions(
            birth_weight_kg=3.2,
            adult_weight_doe_kg=40.0,  # NBAGR breed descriptor
            adult_weight_buck_kg=46.0,
            weight_by_age_months=_scaled_weights(1.2, 3.2),
        ),
    )
    return apply_system(a, system)


def black_bengal(system: System = "stall_fed") -> SimulationAssumptions:
    """Black Bengal: small, very prolific, early-maturing meat/skin breed."""
    a = SimulationAssumptions(
        herd=HerdAssumptions(
            doe_purchase_price=4500.0,  # small-framed breed
            buck_purchase_price=6000.0,
        ),
        reproduction=ReproductionAssumptions(
            litter_size=2.0,  # NBAGR: twins/triplets common
            age_at_first_breeding_months=9,
        ),
        growth=GrowthAssumptions(
            birth_weight_kg=1.5,
            adult_weight_doe_kg=18.0,  # NBAGR breed descriptor
            adult_weight_buck_kg=20.0,
            weight_by_age_months=_scaled_weights(0.55, 1.5),
            sale_age_months=8,
        ),
        mortality=MortalityAssumptions(kid_pre_weaning=0.12),  # small kids, fragile
    )
    return apply_system(a, system)


def boer_cross(system: System = "stall_fed") -> SimulationAssumptions:
    """Boer cross: fast-growing terminal meat cross, premium carcass."""
    a = SimulationAssumptions(
        herd=HerdAssumptions(
            doe_purchase_price=10000.0,  # crossbred premium
            buck_purchase_price=18000.0,
        ),
        reproduction=ReproductionAssumptions(
            litter_size=1.7,
            age_at_first_breeding_months=12,
        ),
        growth=GrowthAssumptions(
            birth_weight_kg=3.0,
            adult_weight_doe_kg=40.0,
            adult_weight_buck_kg=50.0,
            # ~2.6 kg/month to yearling: Boer-cross growth rates (ICAR AICRP).
            weight_by_age_months=[3.0 + 2.6 * m for m in range(13)],
            sale_age_months=8,
        ),
        sales=SalesAssumptions(meat_price_per_kg=400.0),  # premium meat cross
    )
    return apply_system(a, system)


PRESET_FACTORIES = {
    "osmanabadi": osmanabadi,
    "sirohi": sirohi,
    "barbari": barbari,
    "jamunapari": jamunapari,
    "beetal": beetal,
    "black_bengal": black_bengal,
    "boer_cross": boer_cross,
}

# Lookup table of stall-fed defaults; use the factories for other systems or
# when a fresh, mutable instance is needed.
BREED_PRESETS: dict[str, SimulationAssumptions] = {
    name: factory() for name, factory in PRESET_FACTORIES.items()
}


def get_preset(breed: str, system: System = "stall_fed") -> SimulationAssumptions:
    """Fresh assumptions for a breed + production system."""
    key = breed.strip().lower().replace(" ", "_").replace("-", "_")
    if key not in PRESET_FACTORIES:
        raise ValueError(f"unknown breed preset: {breed!r} (have {sorted(PRESET_FACTORIES)})")
    return PRESET_FACTORIES[key](system)


__all__ = [
    "BREED_PRESETS",
    "PRESET_FACTORIES",
    "SYSTEMS",
    "System",
    "apply_system",
    "get_preset",
]
