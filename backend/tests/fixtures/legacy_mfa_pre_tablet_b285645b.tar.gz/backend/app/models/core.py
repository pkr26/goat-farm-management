"""Multi-tenancy: users, farms, roles, memberships, refresh sessions."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import (
    CheckConstraint,
    ForeignKey,
    ForeignKeyConstraint,
    Index,
    String,
    UniqueConstraint,
    text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..db import Base, JSONText
from ..permissions import ROLE_PRESET_CODES
from ..utils import utcnow

if TYPE_CHECKING:
    from .animals import Animal

logger = logging.getLogger("goatfarm.models")

_ROLE_PRESET_CODES_SQL = ", ".join(f"'{code}'" for code in sorted(ROLE_PRESET_CODES))


class User(Base):
    __tablename__ = "users"
    __table_args__ = (
        CheckConstraint(
            "deleted_at IS NULL OR (name IS NULL AND email LIKE 'deleted-%@deleted.invalid')",
            name="ck_users_deleted_profile_scrubbed",
        ),
        Index(
            "ix_users_deleted_id",
            "id",
            postgresql_where=text("deleted_at IS NOT NULL"),
        ),
        CheckConstraint(
            "totp_state IS NULL OR totp_state IN ('PENDING', 'ACTIVE')",
            name="ck_users_totp_state",
        ),
        CheckConstraint(
            "(totp_secret_enc IS NULL) = (totp_state IS NULL)",
            name="ck_users_totp_secret_pairs_with_state",
        ),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    name: Mapped[str | None] = mapped_column(String(120))
    password_hash: Mapped[str] = mapped_column(String(255))
    # Owner-provisioned credentials (worker create / password reset) force a
    # self-service rotation before any domain mutation: the owner chooses
    # (and can re-acquire) those passwords, so worker-attributed records keep
    # non-repudiation only once the worker has taken sole possession.
    must_change_password: Mapped[bool] = mapped_column(
        default=False, server_default=text("false"), nullable=False
    )
    # Included in access JWTs and checked on every authenticated request.
    # Password changes/resets and logout increment the value so already-issued
    # bearer tokens stop working immediately. Farm-membership deactivation is
    # tenant-local and is enforced by the membership lookup instead; it must
    # not log the same global account out of unrelated farms.
    token_version: Mapped[int] = mapped_column(default=0, server_default="0")
    # TOTP second factor (HUM-1 follow-up, 2026-09-16). The secret is stored
    # AES-GCM encrypted under a key derived from the JWT signing key — never
    # plaintext. state: NULL = never enrolled, PENDING = enroll started but
    # unconfirmed (not yet demanded at login), ACTIVE = demanded at login.
    # last_step is the replay high-water mark (a used code never re-validates).
    totp_secret_enc: Mapped[bytes | None]
    totp_state: Mapped[str | None] = mapped_column(String(7))
    totp_last_step: Mapped[int | None]
    # UTC server default standardized by the D7 completion wave (2026-09-29).
    created_at: Mapped[datetime] = mapped_column(
        default=utcnow, server_default=text("timezone('UTC', now())")
    )
    # Account deletion keeps a pseudonymous row so immutable farm/audit
    # attribution survives. Authentication dependencies reject tombstones;
    # deletion scrubs the email, name and reusable password material.
    deleted_at: Mapped[datetime | None]

    farms: Mapped[list[Farm]] = relationship(back_populates="owner")
    memberships: Mapped[list[FarmMembership]] = relationship(back_populates="user")

    @property
    def display_name(self) -> str:
        if self.deleted_at is not None:
            return "Deleted account"
        return self.name or self.email


class TotpRecoveryCode(Base):
    """One single-use break-glass code for the TOTP second factor.

    Minted only at enrollment confirmation or an explicit (password + TOTP
    proof) regeneration; shown to the user exactly once and never stored in
    the clear. ``used_at`` is the single-use marker: a spent code stays in the
    table as the audit trail of WHEN it redeemed, but can never validate
    again. Deleting the account (CASCADE) removes the hashes with it; TOTP
    disable/regenerate purges and remints the set atomically.
    """

    __tablename__ = "totp_recovery_codes"
    __table_args__ = (
        # The challenge path scans exactly this shape: the owner's unused
        # codes, oldest first, FOR UPDATE.
        Index("ix_totp_recovery_codes_user_used", "user_id", "used_at", "id"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    code_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    used_at: Mapped[datetime | None] = mapped_column()
    # UTC server default standardized by the housekeeping wave (2026-09-28
    # audit, D7).
    created_at: Mapped[datetime] = mapped_column(
        default=utcnow, server_default=text("timezone('UTC', now())")
    )


class ConsumedMfaChallenge(Base):
    """A TOTP challenge token that has completed its one successful exchange.

    The single-use property (RFC 6238: the verifier MUST detect replay of a
    used one-time-password exchange) lives in the database, not process
    memory, so it survives restarts and holds under any future multi-replica
    topology (2026-10-01 audit, 01-3 — decided 2026-10-02: durable storage
    replaces the previously accepted per-process tradeoff). The claim rides
    the login-success transaction — the insert commits exactly when the
    exchange succeeds, so a failed request never burns a challenge and a
    committed success is consumed forever. ``expires_at`` is the token's
    signed expiry; the verify path sweeps expired rows opportunistically, so
    the table is bounded by successful exchanges since the last sweep.
    """

    __tablename__ = "consumed_mfa_challenges"

    jti: Mapped[str] = mapped_column(String(64), primary_key=True)
    expires_at: Mapped[datetime] = mapped_column(nullable=False)
    consumed_at: Mapped[datetime] = mapped_column(
        default=utcnow, server_default=text("timezone('UTC', now())")
    )


class Farm(Base):
    __tablename__ = "farms"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    location: Mapped[str | None] = mapped_column(String(120))
    timezone: Mapped[str] = mapped_column(
        String(64), default="Asia/Kolkata", server_default="Asia/Kolkata"
    )
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="RESTRICT"), index=True)
    # UTC server default standardized by the D7 completion wave (2026-09-29).
    created_at: Mapped[datetime] = mapped_column(
        default=utcnow, server_default=text("timezone('UTC', now())")
    )
    # Refresh is SQLAlchemy-layer only: ``onupdate`` covers ORM flushes AND
    # Core ``update()`` statements, but ``server_onupdate`` emits no DDL and
    # farms deliberately carries no DB trigger — no production writer
    # targets it with raw SQL (2026-10-01 audit, 04-2). Display/audit
    # metadata only, never a concurrency token.
    updated_at: Mapped[datetime] = mapped_column(
        default=utcnow,
        onupdate=utcnow,
        server_default=text("timezone('UTC', now())"),
        server_onupdate=text("timezone('UTC', now())"),
    )

    owner: Mapped[User] = relationship(back_populates="farms")
    animals: Mapped[list[Animal]] = relationship(back_populates="farm")
    roles: Mapped[list[Role]] = relationship(back_populates="farm", cascade="all, delete-orphan")
    memberships: Mapped[list[FarmMembership]] = relationship(
        back_populates="farm", cascade="all, delete-orphan"
    )


class Role(Base):
    """Farm-scoped role: a named bundle of permission codes (JSON list).

    Preset roles carry a stable `code` (MOVER, VET, ...) used to map
    auto-generated tasks to a default assignee; custom roles have code=None.
    """

    __tablename__ = "roles"
    __table_args__ = (
        UniqueConstraint("farm_id", "id", name="uq_roles_farm_id_id"),
        CheckConstraint("revision >= 1", name="ck_roles_revision_positive"),
        CheckConstraint(
            f"code IS NULL OR code IN ({_ROLE_PRESET_CODES_SQL})",
            name="ck_roles_preset_code",
        ),
        # Permissions are a jsonb array at the storage layer; the shape check
        # makes a wrong-shape write fail in PostgreSQL, not at the next read.
        CheckConstraint(
            "jsonb_typeof(permissions) = 'array'",
            name="ck_roles_permissions_json_array",
        ),
        Index(
            "uq_roles_farm_active_name",
            "farm_id",
            "name",
            unique=True,
            postgresql_where=text("deleted_at IS NULL"),
        ),
        # ``code`` is the stable identity used to route generated duties to a
        # farm's preset role. Names and permissions are editable, so neither
        # can disambiguate duplicate preset rows. Tombstones stay covered: a
        # retired preset identity must not be silently reused by another row.
        Index(
            "uq_roles_farm_preset_code",
            "farm_id",
            "code",
            unique=True,
            postgresql_where=text("code IS NOT NULL"),
        ),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    farm_id: Mapped[int] = mapped_column(ForeignKey("farms.id"), index=True)
    code: Mapped[str | None] = mapped_column(String(30))  # preset key; null for custom roles
    name: Mapped[str] = mapped_column(String(80))
    description: Mapped[str | None] = mapped_column(String(255))
    # JSON array of permission codes, stored as jsonb (CHECK-enforced array
    # shape; see ck_roles_permissions_json_array). The ORM attribute keeps the
    # historical JSON-text interface — readers json.loads, writers json.dumps —
    # via db.JSONText.
    permissions: Mapped[str] = mapped_column(JSONText, default="[]")
    # Optimistic-concurrency token for full-role edits.  A row lock only
    # serializes writers; it cannot tell that a second editor built its full
    # permissions payload from stale state.
    revision: Mapped[int] = mapped_column(default=1, server_default="1")
    # UTC server default standardized by the D7 completion wave (2026-09-29).
    created_at: Mapped[datetime] = mapped_column(
        default=utcnow, server_default=text("timezone('UTC', now())")
    )
    # Custom-role deletion is a tombstone, not an unbounded rewrite of every
    # historical Task that referenced the role. Active role queries exclude
    # tombstones; task audit rows may keep this immutable identity/name.
    deleted_at: Mapped[datetime | None]

    farm: Mapped[Farm] = relationship(back_populates="roles")
    memberships: Mapped[list[FarmMembership]] = relationship(
        back_populates="role", foreign_keys="FarmMembership.role_id"
    )

    def permission_set(self) -> set[str]:
        if self.deleted_at is not None:
            return set()
        import json

        try:
            decoded = json.loads(self.permissions or "[]")
        except ValueError:
            decoded = None
        # The shape matters as much as the syntax: valid JSON that is not a
        # list ("null", "5") would raise TypeError past this guard, and a bare
        # string would silently decompose into its characters.
        if not isinstance(decoded, list):
            # Fail-closed is right, but not silently: a corrupt
            # row locks the role's workers out of everything.
            logger.warning("Role id=%s has corrupt permissions JSON — treating as empty", self.id)
            return set()
        return {p for p in decoded if isinstance(p, str)}


class FarmMembership(Base):
    """Links a User to a Farm as a worker with a Role. The farm owner is not
    a membership — ownership (Farm.owner_id) implies all permissions."""

    __tablename__ = "farm_memberships"
    __table_args__ = (
        # Both orders stay (2026-09-28 audit review): (farm_id, user_id) is
        # the tenant composite-FK target, and (user_id, farm_id) is the only
        # index serving the user→farms affiliation lookups that carry no
        # is_active predicate (api/auth.py's membership list, api/team.py's
        # owns-other-farm probe) — the partial index below cannot serve
        # those, so dropping this constraint would seq-scan them.
        UniqueConstraint("user_id", "farm_id", name="uq_membership_user_farm"),
        UniqueConstraint("farm_id", "user_id", name="uq_farm_memberships_farm_user"),
        # Tenant candidate key: notification_recipients' composite
        # (farm_id, membership_id) FK targets it, so a recipient row can
        # never point across farms (2026-09-29 audit, L2 — roles carries
        # the same guard for the farm_role FK).
        UniqueConstraint("farm_id", "id", name="uq_farm_memberships_farm_id_id"),
        Index(
            "ix_farm_memberships_active_user_id_id",
            "user_id",
            "id",
            postgresql_where=text("is_active IS TRUE"),
        ),
        ForeignKeyConstraint(
            ["farm_id", "role_id"],
            ["roles.farm_id", "roles.id"],
            name="fk_farm_memberships_farm_role",
            ondelete="RESTRICT",
        ),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    farm_id: Mapped[int] = mapped_column(ForeignKey("farms.id", ondelete="CASCADE"), index=True)
    role_id: Mapped[int] = mapped_column(ForeignKey("roles.id", ondelete="RESTRICT"), index=True)
    is_active: Mapped[bool] = mapped_column(default=True)
    # True only when this farm created the underlying global User. Legacy and
    # externally registered accounts fail closed: their password may not be
    # rewritten by a farm manager.
    account_provisioned_by_farm: Mapped[bool] = mapped_column(default=False, server_default="false")
    # Worker-tablet quick sign-in (ITEM 2, 2026-09-21 playbook): an Argon2id
    # hash of this membership's short numeric PIN. Null on memberships that
    # never opted into PIN login. The account password stays the account's
    # real credential — a PIN is scoped to THIS membership and survives none
    # of the account-level password machinery.
    pin_hash: Mapped[str | None] = mapped_column(String(255))
    pin_updated_at: Mapped[datetime | None] = mapped_column()
    # UTC server default standardized by the D7 completion wave (2026-09-29).
    created_at: Mapped[datetime] = mapped_column(
        default=utcnow, server_default=text("timezone('UTC', now())")
    )

    user: Mapped[User] = relationship(back_populates="memberships")
    farm: Mapped[Farm] = relationship(back_populates="memberships")
    role: Mapped[Role] = relationship(back_populates="memberships", foreign_keys=[role_id])


class RefreshSession(Base):
    """Server-side record of one issued refresh token.

    Every refresh JWT's jti lands here at issue time; /refresh consumes the
    presented row and inserts its successor into the same rotation family.
    Re-presenting a consumed or revoked jti means a rotated-away token was
    replayed — theft per RFC 6819 §5.2.2.3 — so the whole family is revoked.
    Logout, password change, and owner-initiated worker password resets revoke
    rows outright. A farm-membership deactivation is intentionally tenant-local
    and leaves the account's global refresh families intact. The jti alone is
    useless without the signing key, so it is stored plain (not hashed).
    """

    __tablename__ = "refresh_sessions"
    __table_args__ = (
        Index("ix_refresh_sessions_expires_id", "expires_at", "id"),
        Index("ix_refresh_sessions_family_created_id", "family_id", "created_at", "id"),
        Index("ix_refresh_sessions_user_created_id", "user_id", "created_at", "id"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    jti: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    family_id: Mapped[str] = mapped_column(String(64))
    expires_at: Mapped[datetime] = mapped_column()
    consumed_at: Mapped[datetime | None] = mapped_column()
    # The successor JTI makes a very short concurrent replay idempotent: two
    # tabs presenting the same cookie receive the exact same replacement
    # token instead of falsely triggering family-wide theft revocation.
    replacement_jti: Mapped[str | None] = mapped_column(String(64))
    revoked_at: Mapped[datetime | None] = mapped_column()
    # UTC server default standardized by the D7 completion wave (2026-09-29).
    created_at: Mapped[datetime] = mapped_column(
        default=utcnow, server_default=text("timezone('UTC', now())")
    )
